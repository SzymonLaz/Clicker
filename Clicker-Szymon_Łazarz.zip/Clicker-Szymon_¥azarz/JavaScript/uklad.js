var uklad = {

    pojemnosc: 25,
    cena: 400,
    ilosc: 0,
    cena_ulepszenia: 300,
    poziom_ulepszenia: 1,

    wymagany_czesci: 30,
    wymagany_zlom: 10,
    wymagany_prad: 25,
    id_okna_ulepszenia: "cena_ulepszenia_mag_ukladow",
    id_okna_tworzenia: "uklad_tworzenie_materialy",


    ulepsz_magazyn: function()
    {
        if(kredyty.ilosc>=uklad.cena_ulepszenia)
        {
            switch(uklad.poziom_ulepszenia)
            {
                case 1:
                    uklad.poziom_ulepszenia=2;
                    uklad.pojemnosc=50;
                    kredyty.ilosc-=uklad.cena_ulepszenia;
                    uklad.cena_ulepszenia=600;
                    wypisywanie();
                    break;
                case 2:
                    uklad.poziom_ulepszenia=3;
                    uklad.pojemnosc=90;
                    kredyty.ilosc-=uklad.cena_ulepszenia;
                    uklad.cena_ulepszenia=800;
                    wypisywanie();
                    break;
                case 3:
                    uklad.poziom_ulepszenia=4;
                    uklad.pojemnosc=160;
                    kredyty.ilosc-=uklad.cena_ulepszenia;
                    uklad.cena_ulepszenia=1000;
                    wypisywanie();
                    break;
                case 4:
                    uklad.poziom_ulepszenia=5; 
                    uklad.pojemnosc=400;
                    kredyty.ilosc-=uklad.cena_ulepszenia;
                    uklad.cena_ulepszenia=1400;
                    wypisywanie();
                    break;
                case 5:
                    uklad.poziom_ulepszenia=6;
                    uklad.pojemnosc=800;
                    kredyty.ilosc-=uklad.cena_ulepszenia;
                    uklad.cena_ulepszenia=1800;
                    wypisywanie();
                    break;
                case 6:
                    uklad.poziom_ulepszenia=7;
                    uklad.pojemnosc=1300;
                    kredyty.ilosc-=uklad.cena_ulepszenia;
                    uklad.cena_ulepszenia=2500;
                    wypisywanie();
                    break;
 
                case 7:
                    uklad.poziom_ulepszenia=8;
                    uklad.pojemnosc=2000;
                    kredyty.ilosc-=uklad.cena_ulepszenia;
                    uklad.cena_ulepszenia="Maks.<br>poziom";
                    wypisywanie();
                    break;

                    
            }

        }
        else
        {
            chwilowy_kolor(2,uklad.id_okna_ulepszenia)
        }
        
    },

    sprzedaj: function()
    {
        if(uklad.ilosc>0)
        {
            uklad.ilosc-=1;
            kredyty.ilosc+=uklad.cena;
            kolor_ukladow();
            wypisywanie();
        }

    },

    stworz: function()
    {
        if(prad.wymagany=="tak")
        {
        if(zlom.ilosc>=uklad.wymagany_zlom && prad.ilosc>=uklad.wymagany_prad && czesci.ilosc>=uklad.wymagany_czesci && uklad.ilosc<uklad.pojemnosc)
        {
            prad.ilosc-=uklad.wymagany_prad;
            zlom.ilosc-=uklad.wymagany_zlom;
            czesci.ilosc-=uklad.wymagany_czesci;
            uklad.ilosc+=1;
            kolor_ukladow();
            kolor_czesci();
            kolor_ukladow();
            wypisywanie();
            

        }
        else
        {
            chwilowy_kolor(2,uklad.id_okna_tworzenia)
        }
        }
        else
        {
            if(zlom.ilosc>=uklad.wymagany_zlom && czesci.ilosc>=uklad.wymagany_czesci && uklad.ilosc<uklad.pojemnosc)
            {
            zlom.ilosc-=uklad.wymagany_zlom;
            czesci.ilosc-=uklad.wymagany_czesci;
            uklad.ilosc+=1;
            kolor_ukladow();
            kolor_czesci();
            kolor_ukladow();
            wypisywanie();
            

            }
            else
            {
            chwilowy_kolor(2,uklad.id_okna_tworzenia)
            }
        }

    },

    sprzedaj_wszystko: function()
    {
        if(uklad.ilosc>0)
        {
            kredyty.ilosc+=(uklad.ilosc*uklad.cena);
            uklad.ilosc=0;
            kolor_ukladow();
            wypisywanie();
        }

    }
}