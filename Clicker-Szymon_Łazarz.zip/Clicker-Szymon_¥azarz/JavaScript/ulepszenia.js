var oko = {
    id_ceny_kupna: "oko_cena",

    kup: function()
    {
        if(kredyty.ilosc>=100000)
        {
            jest_oko=2;
            kredyty.ilosc-=100000;
            document.getElementById("ulepszenie1").innerHTML="MASZ";

        }
        else
        {
            chwilowy_kolor(2,oko.id_ceny_kupna)
        }

    }

}


var kamien = {
    id_ceny_kupna: "kamien_cena",

    kup: function()
    {
        if(kredyty.ilosc>=600000)
        {
            zlom.cena=4;
            czesci.cena=20;
            uklad.cena=800;
            zaawansowany.cena=20000;
            wibranium.cena=4000000;
            document.getElementById("cena_wibranium").innerHTML="4 000 000"
            wypisywanie();
            document.getElementById("ulepszenie2").innerHTML="MASZ";

        }
        else
        {
            chwilowy_kolor(2,kamien.id_ceny_kupna)
        }
    }

}


var glob = {
    id_ceny_kupna: "glob_cena",

    kup: function()
    {
        if(kredyty.ilosc>=300000)
        {
            prad.wymagany="nie";
            czesci.wymagany_prad=0;
            uklad.wymagany_prad=0;
            zaawansowany.wymagany_prad=0;
            legion.prad=0;
            prad.ilosc="nieskończoność"
            document.getElementById("ilosc_pradu").style.backgroundColor="rgb(73, 73, 73)";
            document.getElementById("guzik_kup_prad").innerHTML="---";
            document.getElementById("cena_pradu_napis").innerHTML="Nie musisz już kupować prądu"
            wypisywanie();
            document.getElementById("ulepszenie3").innerHTML="MASZ";


        }
        else
        {
            chwilowy_kolor(2,glob.id_ceny_kupna)
        }
    }

}