var stabilizator = {

    ilosc: 0,

    wymagany_zaawansowany: 100,
    wymagany_kredyty: 400000,
    id_okna_tworzenia: "stabilizator_tworzenie_materialy",

    stworz: function()
    {
        if(zaawansowany.ilosc>=stabilizator.wymagany_zaawansowany && kredyty.ilosc>=stabilizator.wymagany_kredyty)
        {
            zaawansowany.ilosc-=stabilizator.wymagany_zaawansowany;
            kredyty.ilosc-=stabilizator.wymagany_kredyty;
            stabilizator.ilosc+=1;
            wypisywanie();
            kolor_zaawansowanych();

        }
        else
        {
            chwilowy_kolor(2,stabilizator.id_okna_tworzenia)
        }

    }
}