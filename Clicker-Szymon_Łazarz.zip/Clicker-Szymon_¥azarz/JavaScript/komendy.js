

function sprawdzanie_kodu()
{
    console.log("kod "+document.getElementById("kody").value);
    switch(document.getElementById("kody").value)
    {
        case "zlomfull":
            zlom.ilosc=zlom.pojemnosc;
            kolor_zlomu();
            wypisywanie();
            document.getElementById("kody").value="";
            break;
        case "czescifull":
            czesci.ilosc=czesci.pojemnosc;
            kolor_czesci();
            wypisywanie();
            document.getElementById("kody").value="";
            break;
        case "ukladyfull":
            uklad.ilosc=uklad.pojemnosc;
            kolor_ukladow();
            wypisywanie();
            document.getElementById("kody").value="";
            break;
        case "zaawansowanefull":
            zaawansowany.ilosc=zaawansowany.pojemnosc;
            kolor_zaawansowanych();
            wypisywanie();
            document.getElementById("kody").value="";
            break;
        case "wibraniumfull":
            wibranium.ilosc=wibranium.pojemnosc;
            kolor_wibranium();
            wypisywanie();
            document.getElementById("kody").value="";
            break;
        case "addmoney":
            kredyty.ilosc+=10000;
            wypisywanie();
            document.getElementById("kody").value="";
            break;
        case "addmoney2":
            kredyty.ilosc+=100000;
            wypisywanie();
            document.getElementById("kody").value="";
            break;
        case "addmoney3":
            kredyty.ilosc+=1000000;
            wypisywanie();
            document.getElementById("kody").value="";
            break;
    }

}