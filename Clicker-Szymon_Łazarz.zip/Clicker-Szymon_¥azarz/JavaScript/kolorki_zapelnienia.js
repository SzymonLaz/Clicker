function chwilowy_kolor(czas,id_okna)
{
    var kolorInterval=setInterval(()=>
    {
        if(czas==0)
        {
            document.getElementById(id_okna).style.backgroundColor="rgb(73, 73, 73)";
            clearInterval(kolorInterval);
        }
        else
        {
            document.getElementById(id_okna).style.backgroundColor="red";
            czas-=1;
            clearInterval(kolorInterval);
            chwilowy_kolor(czas,id_okna);
        }

    },500);

}

function kolor_pradu()
{
    if(prad.ilosc!="nieskończoność")
    {
    if(prad.ilosc<10)
    {
        document.getElementById("ilosc_pradu").style.backgroundColor="red";
    }
    else
    {
        document.getElementById("ilosc_pradu").style.backgroundColor="rgb(73, 73, 73)";
    }
    }
};

function kolor_zlomu()
{
    if(100*(zlom.ilosc/zlom.pojemnosc)>=0)
    {
        document.getElementById("ilosc_zlomu").style.backgroundColor="green";
    }
    if(100*(zlom.ilosc/zlom.pojemnosc)>80)
    {
        document.getElementById("ilosc_zlomu").style.backgroundColor="yellow";
    }
    if(zlom.ilosc>=zlom.pojemnosc)
    {
        zlom.ilosc=zlom.pojemnosc;
        document.getElementById("ilosc_zlomu").style.backgroundColor="red";
    }
};

function kolor_czesci()
{
    if(100*(czesci.ilosc/czesci.pojemnosc)>=0)
    {
        document.getElementById("ilosc_czesci").style.backgroundColor="green";
    }
    if(100*(czesci.ilosc/czesci.pojemnosc)>80)
    {
        document.getElementById("ilosc_czesci").style.backgroundColor="yellow";
    }
    if(czesci.ilosc>=czesci.pojemnosc)
    {
        czesci.ilosc=czesci.pojemnosc;
        document.getElementById("ilosc_czesci").style.backgroundColor="red";
    }
};

function kolor_ukladow()
{
    if(100*(uklad.ilosc/uklad.pojemnosc)>=0)
    {
        document.getElementById("ilosc_ukladow").style.backgroundColor="green";
    }
    if(100*(uklad.ilosc/uklad.pojemnosc)>80)
    {
        document.getElementById("ilosc_ukladow").style.backgroundColor="yellow";
    }
    if(uklad.ilosc>=uklad.pojemnosc)
    {
        uklad.ilosc=uklad.pojemnosc;
        document.getElementById("ilosc_ukladow").style.backgroundColor="red";
    }
};

function kolor_zaawansowanych()
{
    if(100*(zaawansowany.ilosc/zaawansowany.pojemnosc)>=0)
    {
        document.getElementById("ilosc_zaawans_uk").style.backgroundColor="green";
    }
    if(100*(zaawansowany.ilosc/zaawansowany.pojemnosc)>80)
    {
        document.getElementById("ilosc_zaawans_uk").style.backgroundColor="yellow";
    }
    if(zaawansowany.ilosc>=zaawansowany.pojemnosc)
    {
        zaawansowany.ilosc=zaawansowany.pojemnosc;
        document.getElementById("ilosc_zaawans_uk").style.backgroundColor="red";
    }
};

function kolor_wibranium()
{
    if(100*(wibranium.ilosc/wibranium.pojemnosc)>=0)
    {
        document.getElementById("ilosc_wibranium").style.backgroundColor="green";
    }
    if(100*(wibranium.ilosc/wibranium.pojemnosc)>80)
    {
        document.getElementById("ilosc_wibranium").style.backgroundColor="yellow";
    }
    if(wibranium.ilosc>=wibranium.pojemnosc)
    {
        wibranium.ilosc=wibranium.pojemnosc;
        document.getElementById("ilosc_wibranium").style.backgroundColor="red";
    }
};