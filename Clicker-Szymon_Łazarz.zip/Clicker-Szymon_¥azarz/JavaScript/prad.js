var prad = {

    cena: 50,
    ilosc: 100,
    wymagany: "tak",

    kup: function()
    {
        if(kredyty.ilosc>=50)
        {
            kredyty.ilosc-=50;
            prad.ilosc+=500;
            wypisywanie();
            kolor_pradu();
        }
    }
}