var czesci = {

    pojemnosc: 50,
    cena: 10,
    ilosc: 0,
    cena_ulepszenia: 100,
    poziom_ulepszenia: 1,
    szansa: 5,

    wymagany_zlom: 4,
    wymagany_prad: 10,
    id_okna_ulepszenia: "cena_ulepszenia_mag_czesci",
    id_okna_tworzenia: "czesci_tworzenie_materialy",

    ulepsz_magazyn: function()
    {
        if(kredyty.ilosc>=czesci.cena_ulepszenia)
        {
            switch(czesci.poziom_ulepszenia)
            {
                case 1:
                    czesci.poziom_ulepszenia=2;
                    czesci.pojemnosc=100;
                    kredyty.ilosc-=czesci.cena_ulepszenia;
                    czesci.cena_ulepszenia=250;
                    wypisywanie();
                    kolor_czesci();
                    break;
                case 2:
                    czesci.poziom_ulepszenia=3;
                    czesci.pojemnosc=200;
                    kredyty.ilosc-=czesci.cena_ulepszenia;
                    czesci.cena_ulepszenia=360;
                    wypisywanie();
                    kolor_czesci();
                    break;
                case 3:
                    czesci.poziom_ulepszenia=4;
                    czesci.pojemnosc=450;
                    kredyty.ilosc-=czesci.cena_ulepszenia;
                    czesci.cena_ulepszenia=450;
                    wypisywanie();
                    kolor_czesci();
                    break;
                case 4:
                    czesci.poziom_ulepszenia=5;
                    czesci.pojemnosc=700;
                    kredyty.ilosc-=czesci.cena_ulepszenia;
                    czesci.cena_ulepszenia=600;
                    wypisywanie();
                    kolor_czesci();
                    break;
                case 5:
                    czesci.poziom_ulepszenia=6;
                    czesci.pojemnosc=1800;
                    kredyty.ilosc-=czesci.cena_ulepszenia;
                    czesci.cena_ulepszenia=800;
                    wypisywanie();
                    kolor_czesci();
                    break;
                case 6:
                    czesci.poziom_ulepszenia=7;
                    czesci.pojemnosc=3000;
                    kredyty.ilosc-=czesci.cena_ulepszenia;
                    czesci.cena_ulepszenia=1000;
                    wypisywanie();
                    kolor_czesci();
                    break;
                case 7:
                    czesci.poziom_ulepszenia=8;
                    czesci.pojemnosc=6000;
                    kredyty.ilosc-=czesci.cena_ulepszenia;
                    czesci.cena_ulepszenia="Maks.<br>poziom";
                    wypisywanie();
                    kolor_czesci();
                    break;

                    
            }

        }
        else
        {
            chwilowy_kolor(2,czesci.id_okna_ulepszenia)
        }
        
        
    },

    sprzedaj: function()
    {
        if(czesci.ilosc>0)
        {
            czesci.ilosc-=1;
            kredyty.ilosc+=czesci.cena;
            kolor_czesci();
            wypisywanie();
        }

    },

    stworz: function()
    {
        if(prad.wymagany=="tak")
        {
        if(zlom.ilosc>=czesci.wymagany_zlom && prad.ilosc>=czesci.wymagany_prad && czesci.ilosc<czesci.pojemnosc)
        {
            prad.ilosc-=czesci.wymagany_prad;
            zlom.ilosc-=czesci.wymagany_zlom;
            czesci.ilosc+=1;
            kolor_czesci();
            kolor_zlomu();
            kolor_pradu();
            wypisywanie();
            

        }
        else
        {
            chwilowy_kolor(2,czesci.id_okna_tworzenia)
        }
        }
        else
        {
            if(zlom.ilosc>=czesci.wymagany_zlom && czesci.ilosc<czesci.pojemnosc)
            {
            zlom.ilosc-=czesci.wymagany_zlom;
            czesci.ilosc+=1;
            kolor_czesci();
            kolor_zlomu();
            kolor_pradu();
            wypisywanie();
            

            }
            else
            {
            chwilowy_kolor(2,czesci.id_okna_tworzenia)
            }

        }

    },

    sprzedaj_wszystko: function()
    {
        if(czesci.ilosc>0)
        {
            kredyty.ilosc+=(czesci.ilosc*czesci.cena);
            czesci.ilosc=0;
            kolor_czesci();
            wypisywanie();
        }

    }
}