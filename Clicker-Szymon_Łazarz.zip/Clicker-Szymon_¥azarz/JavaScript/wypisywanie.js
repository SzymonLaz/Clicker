function wypisywanie()
{
    document.getElementById("ilosc_stabilizatorow").innerHTML=stabilizator.ilosc;
    document.getElementById("prad_wibranium").innerHTML=wibranium.wymagany_prad*stabilizator.ilosc;
    document.getElementById("cena_ulepszenia_legion").innerHTML="Cena ulepszenia<br>"+legion.cena_ulepszenia+"<br>(Zwiększa szansę na części)";
    document.getElementById("cena_kupienia_legion").innerHTML="Cena kupna<br>"+legion.cena;
    document.getElementById("ilosc_iron_legion").innerHTML=legion.ilosc;
    document.getElementById("prad_iron_legion").innerHTML=legion.ilosc*legion.prad;
    document.getElementById("czesci_szansa").innerHTML=czesci.szansa+"%";
    document.getElementById("ilosc_kredytow").innerHTML="Posiadasz<br>"+kredyty.ilosc;
    document.getElementById("ilosc_pradu").innerHTML="Posiadasz<br>"+prad.ilosc;
    document.getElementById("ilosc_zlomu").innerHTML=zlom.ilosc+"/"+zlom.pojemnosc;
    document.getElementById("cena_ulepszenia_mag_zlomu").innerHTML=zlom.cena_ulepszenia;
    document.getElementById("cena_zlomu").innerHTML=zlom.cena;
    document.getElementById("ilosc_czesci").innerHTML=czesci.ilosc+"/"+czesci.pojemnosc;
    document.getElementById("cena_ulepszenia_mag_czesci").innerHTML=czesci.cena_ulepszenia;
    document.getElementById("cena_czesci").innerHTML=czesci.cena;
    document.getElementById("ilosc_ukladow").innerHTML=uklad.ilosc+"/"+uklad.pojemnosc;
    document.getElementById("cena_ulepszenia_mag_ukladow").innerHTML=uklad.cena_ulepszenia;
    document.getElementById("cena_ukladu").innerHTML=uklad.cena;
    document.getElementById("ilosc_zaawans_uk").innerHTML=zaawansowany.ilosc+"/"+zaawansowany.pojemnosc;
    document.getElementById("cena_ulepszenia_mag_zaawans").innerHTML=zaawansowany.cena_ulepszenia;
    document.getElementById("cena_zaawansowanego_ukladu").innerHTML=zaawansowany.cena;
    document.getElementById("ilosc_wibranium").innerHTML=wibranium.ilosc+"/"+wibranium.pojemnosc;
    document.getElementById("cena_ulepszenia_mag_wibranium").innerHTML=wibranium.cena_ulepszenia;
    
}