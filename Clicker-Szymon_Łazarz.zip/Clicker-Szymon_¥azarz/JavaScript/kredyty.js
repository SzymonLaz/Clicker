var kredyty = {

    ilosc: 0,

}