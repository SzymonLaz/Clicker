var jest_oko=1;

var legion = {

    cena: 500,
    ilosc: 1,
    cena_ulepszenia: 400,
    prad: 2,
    poziom_ulepszenia: 1,
    id_okna_ulepszenia: "cena_ulepszenia_legion",
    id_okna_kupna: "cena_kupienia_legion",

    ulepsz: function()
    {
        if(kredyty.ilosc>=legion.cena_ulepszenia)
        {
            if(legion.poziom_ulepszenia==4)
            {
                console.log("Ulepszono Iron Legion to poziomu 5");
                kredyty.ilosc-=legion.cena_ulepszenia;
                legion.poziom_ulepszenia=5;
                legion.cena_ulepszenia="---";
                czesci.szansa=70;
                document.getElementById("guzik_do_ulepszania_legion").innerHTML="Maks.<br>poziom";
                wypisywanie();
            }
            if(legion.poziom_ulepszenia==3)
            {
                console.log("Ulepszono Iron Legion to poziomu 4");
                kredyty.ilosc-=legion.cena_ulepszenia;
                legion.poziom_ulepszenia=4;
                legion.cena_ulepszenia=2000;
                czesci.szansa=40;
                wypisywanie();
            }
            if(legion.poziom_ulepszenia==2)
            {
                console.log("Ulepszono Iron Legion to poziomu 3");
                kredyty.ilosc-=legion.cena_ulepszenia;
                legion.poziom_ulepszenia=3;
                legion.cena_ulepszenia=1200;
                czesci.szansa=25;
                wypisywanie();
            }
            if(legion.poziom_ulepszenia==1)
            {
                console.log("Ulepszono Iron Legion to poziomu 2");
                kredyty.ilosc-=legion.cena_ulepszenia;
                legion.poziom_ulepszenia=2;
                legion.cena_ulepszenia=800;
                czesci.szansa=10;
                wypisywanie();
            }
            
            

        }
        else
        {
            chwilowy_kolor(2,legion.id_okna_ulepszenia);

        }
        
    },

    zbieraj: function()
    {
        if(prad.wymagany=="tak")
        {
            kolor_pradu();
            if(prad.ilosc>=legion.ilosc*2)
            {
                document.getElementById("prad_iron_legion").style.backgroundColor="rgb(73, 73, 73)";
                prad.ilosc-=legion.ilosc*2;
                zlom.ilosc+=legion.ilosc*jest_oko;
                kolor_zlomu();
                czy_sa_czesci();
                kolor_czesci()
                kolor_pradu();
                wypisywanie();
    
            }
            else
            {
                document.getElementById("prad_iron_legion").style.backgroundColor="red";
                console.log("Za mało prądu w Iron Legion");
                kolor_pradu();
                wypisywanie();
            }
    
        }
        else
        {
                document.getElementById("prad_iron_legion").style.backgroundColor="rgb(73, 73, 73)";
                zlom.ilosc+=legion.ilosc*jest_oko;
                kolor_zlomu();
                czy_sa_czesci();
                kolor_czesci()
                wypisywanie();
    
        }
    },

    kup: function()
    {
        if(kredyty.ilosc>=legion.cena)
        {
            legion.ilosc+=1;
            kredyty.ilosc-=legion.cena;
            wypisywanie();
            console.log("Kupiono Iron Legion za "+legion.cena+" kredytów");
        }
        else
        {
            chwilowy_kolor(2,legion.id_okna_kupna);
        }

    }
}

