var wibranium = {

    pojemnosc: 5,
    cena: 2000000,
    ilosc: 0,
    cena_ulepszenia: 1000000,
    poziom_ulepszenia: 1,
    wymagany_prad: 10000,
    id_okna_ulepszenia: "cena_ulepszenia_mag_wibranium",
    id_wymaganego_pradu: "prad_wibranium",

    ulepsz_magazyn: function()
    {
        if(kredyty.ilosc>=wibranium.cena_ulepszenia)
        {
            switch(wibranium.poziom_ulepszenia)
            {
                case 1:
                    wibranium.poziom_ulepszenia=2;
                    wibranium.pojemnosc=12;
                    kredyty.ilosc-=wibranium.cena_ulepszenia;
                    wibranium.cena_ulepszenia=2200000;
                    wypisywanie();
                    kolor_wibranium();
                    break;
                case 2:
                    wibranium.poziom_ulepszenia=3;
                    wibranium.pojemnosc=25;
                    kredyty.ilosc-=wibranium.cena_ulepszenia;
                    wibranium.cena_ulepszenia=3500000;
                    wypisywanie();
                    kolor_zaawansowanych();
                    break;
                case 3:
                    wibranium.poziom_ulepszenia=4;
                    wibranium.pojemnosc=40;
                    kredyty.ilosc-=wibranium.cena_ulepszenia;
                    wibranium.cena_ulepszenia=5000000;
                    wypisywanie();
                    kolor_wibranium();
                    break;
                case 4:
                    wibranium.poziom_ulepszenia=5;
                    wibranium.pojemnosc=65;
                    kredyty.ilosc-=wibranium.cena_ulepszenia;
                    wibranium.cena_ulepszenia=7500000;
                    wypisywanie();
                    kolor_wibranium();
                    break;
                case 5:
                    wibranium.poziom_ulepszenia=6;
                    wibranium.pojemnosc=90;
                    kredyty.ilosc-=wibranium.cena_ulepszenia;
                    wibranium.cena_ulepszenia=10000000;
                    wypisywanie();
                    kolor_wibranium();
                    break;
                case 6:
                    wibranium.poziom_ulepszenia=7;
                    wibranium.pojemnosc=140;
                    kredyty.ilosc-=wibranium.cena_ulepszenia;
                    wibranium.cena_ulepszenia=15000000;
                    wypisywanie();
                    kolor_wibranium();
                    break;
 
                case 7:
                    wibranium.poziom_ulepszenia=8;
                    wibranium.pojemnosc=200;
                    kredyty.ilosc-=wibranium.cena_ulepszenia;
                    wibranium.cena_ulepszenia="Maks.<br>poziom";
                    wypisywanie();
                    kolor_wibranium();
                    break;

                    
            }

        }
        else
        {
            chwilowy_kolor(2,wibranium.id_okna_ulepszenia)
        }
        
    },

    sprzedaj: function()
    {
        if(wibranium.ilosc>0)
        {
            wibranium.ilosc-=1;
            kredyty.ilosc+=wibranium.cena;
            kolor_wibranium();
            wypisywanie();
        }

    },

    zbieraj: function()
    {
        if(prad.wymagany=="tak")
        {
        if(prad.ilosc>=(wibranium.wymagany_prad*stabilizator.ilosc) && wibranium.ilosc<wibranium.pojemnosc)
        {
            prad.ilosc-=(wibranium.wymagany_prad*stabilizator.ilosc);
            wibranium.ilosc+=stabilizator.ilosc;
            wypisywanie();
            kolor_wibranium();

        }
        else
        {
            chwilowy_kolor(2,wibranium.id_wymaganego_pradu)
        }
        }
        else
        {
            if(wibranium.ilosc<wibranium.pojemnosc)
            {
            wibranium.ilosc+=stabilizator.ilosc;
            wypisywanie();
            kolor_wibranium();

            }
            else
            {
            chwilowy_kolor(2,wibranium.id_wymaganego_pradu)
            }
        }
    },

    sprzedaj_wszystko: function()
    {
        if(wibranium.ilosc>0)
        {
            kredyty.ilosc+=(wibranium.ilosc*wibranium.cena);
            wibranium.ilosc=0;
            kolor_wibranium();
            wypisywanie();
        }

    }
}